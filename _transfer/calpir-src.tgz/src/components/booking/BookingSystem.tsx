"use client";

import React, { useEffect, useState } from 'react';
import { format, addDays, startOfDay, isBefore, addMinutes, parse, setHours, setMinutes } from 'date-fns';
import { formatInTimeZone } from 'date-fns-tz';
import { Calendar as CalendarIcon, Clock, User, CheckCircle2, ArrowRight, Loader2, Globe } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { cn } from '@/lib/utils';
import { showSuccess, showError } from '@/utils/toast';
import { trackLeadGeneration } from '@/utils/analytics';

const timezones = [
  { value: "Europe/London", label: "London (GMT / BST)" },
  { value: "America/New_York", label: "New York (EST / EDT)" },
  { value: "America/Chicago", label: "Chicago (CST / CDT)" },
  { value: "America/Los_Angeles", label: "Los Angeles (PST / PDT)" },
  { value: "Europe/Paris", label: "Paris / Berlin (CET / CEST)" },
  { value: "Asia/Dubai", label: "Dubai (GST)" },
  { value: "Asia/Singapore", label: "Singapore / HK (SGT)" },
  { value: "Australia/Sydney", label: "Sydney (AEST / AEDT)" }
];

interface BookingSystemProps {
  /** Email the visitor already typed in the hero, so they do not type it twice. */
  initialEmail?: string;
  /** Drop the card chrome when rendered inside the popup, which supplies its own. */
  bare?: boolean;
}

const BookingSystem: React.FC<BookingSystemProps> = ({ initialEmail = '', bare = false }) => {
  const [selectedDate, setSelectedDate] = useState<Date>(addDays(startOfDay(new Date()), 1));
  const [selectedTime, setSelectedTime] = useState<string | null>(null);
  const [userTimezone, setUserTimezone] = useState(Intl.DateTimeFormat().resolvedOptions().timeZone || "Europe/London");
  const [step, setStep] = useState(1);
  const [botField, setBotField] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [formData, setFormData] = useState({ name: '', email: initialEmail, businessNotes: '' });
  const [slots, setSlots] = useState<Array<{ time: string; available: boolean }> | null>(null);
  const [loadingSlots, setLoadingSlots] = useState(false);
  const [meetLink, setMeetLink] = useState<string | null>(null);

  const generateTimeSlots = () => {
    const slots: string[] = [];
    let current = setMinutes(setHours(new Date(), 10), 0);
    const end = setMinutes(setHours(new Date(), 19), 30);

    while (isBefore(current, addMinutes(end, 1))) {
      slots.push(format(current, 'HH:mm'));
      current = addMinutes(current, 30);
    }
    return slots;
  };

  const timeSlots = generateTimeSlots();

  // Ask the server which slots are genuinely free on the calendar that day.
  useEffect(() => {
    let cancelled = false;
    setLoadingSlots(true);
    fetch(`/api/availability?date=${format(selectedDate, 'yyyy-MM-dd')}`)
      .then((r) => (r.ok ? r.json() : Promise.reject(new Error(String(r.status)))))
      .then((data) => { if (!cancelled) setSlots(Array.isArray(data?.slots) ? data.slots : null); })
      // If availability is unreachable, offer every slot rather than an empty
      // calendar. A clash is recoverable; a page that looks broken is not.
      .catch(() => { if (!cancelled) setSlots(null); })
      .finally(() => { if (!cancelled) setLoadingSlots(false); });
    return () => { cancelled = true; };
  }, [selectedDate]);

  const isSlotFree = (time: string) => {
    if (!slots) return true;
    const hit = slots.find((s) => s.time === time);
    return hit ? hit.available : true;
  };

  // Drop a chosen time that stopped being free after the date changed.
  useEffect(() => {
    if (selectedTime && !isSlotFree(selectedTime)) setSelectedTime(null);
  }, [slots]);

  const convertToUserTime = (ukTime: string) => {
    try {
      const today = format(selectedDate, 'yyyy-MM-dd');
      const ukDateTime = `${today} ${ukTime}`;
      const date = parse(ukDateTime, 'yyyy-MM-dd HH:mm', new Date());
      return formatInTimeZone(date, userTimezone, 'HH:mm');
    } catch {
      return ukTime;
    }
  };

  const handleBooking = async (e: React.FormEvent) => {
    e.preventDefault();
    // Honeypot: only a bot fills this in.
    if (botField.trim() !== '') return;
    setIsSending(true);

    try {
      const response = await fetch('/api/book', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({
          _gotcha: botField,
          name: formData.name,
          email: formData.email,
          date: format(selectedDate, 'yyyy-MM-dd'),
          time: selectedTime,
          timezone: userTimezone,
          notes: formData.businessNotes,
        }),
      });
      const data = await response.json().catch(() => ({}));

      if (response.ok && data?.ok) {
        trackLeadGeneration("booking_system");
        setMeetLink(data.meetLink || null);
        showSuccess(`Booked. The calendar invite is on its way to ${formData.email}.`);
        setStep(3);
      } else {
        if (response.status === 409) {
          // Someone took the slot while they were filling the form in.
          setSelectedTime(null);
          setStep(1);
        }
        showError(data?.error || "Booking failed. Please email info@calpir.com to lock in your time.");
      }
    } catch (err) {
      showError("Connection error. Please reach out to info@calpir.com or call +44 7346 875731.");
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className={bare ? "bg-white p-4 sm:p-6 md:p-8" : "border border-slate-200 bg-white p-4 sm:p-6 md:p-10 shadow-lg"}>
      {step === 1 && (
        <div className="space-y-6 sm:space-y-8">
          <div className="flex items-center gap-3.5 sm:gap-5 pb-5 sm:pb-6 border-b border-slate-200">
            <div className="w-12 h-12 sm:w-14 sm:h-14 bg-emerald-600 flex items-center justify-center shrink-0 text-white shadow-sm">
              <User size={24} className="sm:w-7 sm:h-7" />
            </div>
            <div>
              <div className="mono text-[10px] sm:text-xs tracking-wide text-emerald-800 font-bold">Squad Lead</div>
              <h3 className="text-xl sm:text-2xl md:text-3xl font-bold text-navy">Maria</h3>
              <p className="mono text-[10px] sm:text-xs text-slate-600 font-bold">30 MINUTE FREE STRATEGY CONSULTATION</p>
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 sm:gap-8">
            <div className="space-y-2.5 sm:space-y-3">
              <label className="mono text-[11px] sm:text-xs tracking-wider text-zinc-800 font-bold flex items-center gap-2">
                <CalendarIcon size={15} className="text-emerald-600" /> 1. Select Date
              </label>
              <div className="grid grid-cols-4 gap-1.5 sm:gap-2">
                {[...Array(8)].map((_, i) => {
                  const date = addDays(startOfDay(new Date()), i + 1);
                  const isSelected = format(date, 'yyyy-MM-dd') === format(selectedDate, 'yyyy-MM-dd');
                  return (
                    <button
                      key={i}
                      type="button"
                      onClick={() => setSelectedDate(date)}
                      className={cn(
                        "p-2 sm:p-3 border mono text-[10px] sm:text-xs flex flex-col items-center transition-all font-bold",
                        isSelected ? "border-emerald-600 bg-emerald-600 text-white shadow-sm" : "border-slate-200 text-slate-600 hover:border-emerald-600 hover:text-navy bg-slate-50"
                      )}
                    >
                      <span className={isSelected ? "text-emerald-100" : "text-slate-500"}>{format(date, 'EEE')}</span>
                      <span className="text-base sm:text-lg font-bold">{format(date, 'dd')}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="space-y-2.5 sm:space-y-3">
              <div className="flex flex-col sm:flex-row sm:justify-between sm:items-center gap-2">
                <label className="mono text-[11px] sm:text-xs tracking-wider text-zinc-800 font-bold flex items-center gap-2">
                  <Clock size={15} className="text-emerald-600" /> 2. Select Time
                </label>
                <div className="w-full sm:w-56">
                  <Select value={userTimezone} onValueChange={setUserTimezone}>
                    <SelectTrigger className="bg-white border-slate-300 mono text-[10px] sm:text-[11px] text-navy h-8 sm:h-9 rounded-xl flex items-center gap-1.5 focus:ring-emerald-600">
                      <Globe size={12} className="text-emerald-600 shrink-0" />
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent className="bg-white border-slate-200 text-navy max-h-64 shadow-xl z-50">
                      {timezones.map((tz) => (
                        <SelectItem key={tz.value} value={tz.value} className="mono text-xs hover:bg-emerald-50 cursor-pointer">
                          {tz.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="grid grid-cols-3 gap-1.5 sm:gap-2 max-h-[180px] sm:max-h-[220px] overflow-y-auto pr-1 custom-scrollbar">
                {timeSlots.map((time) => {
                  const free = isSlotFree(time);
                  return (
                    <button
                      key={time}
                      type="button"
                      disabled={!free || loadingSlots}
                      title={free ? undefined : 'Already booked'}
                      onClick={() => setSelectedTime(time)}
                      className={cn(
                        "p-2 sm:p-2.5 border mono text-[11px] sm:text-xs font-bold transition-all",
                        !free
                          ? "border-slate-100 text-zinc-300 bg-slate-50 line-through cursor-not-allowed"
                          : selectedTime === time
                            ? "border-emerald-600 bg-emerald-600 text-white shadow-sm"
                            : "border-slate-200 text-slate-600 hover:border-emerald-600 hover:text-navy bg-slate-50",
                        loadingSlots && "opacity-60"
                      )}
                    >
                      {convertToUserTime(time)}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>

          <Button 
            type="button"
            disabled={!selectedTime}
            onClick={() => setStep(2)}
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-5 sm:py-6 rounded-xl font-bold text-sm sm:text-lg tracking-tight btn-hover"
          >
            Confirm Time Slot <ArrowRight className="ml-2" size={16} />
          </Button>
        </div>
      )}

      {step === 2 && (
        <form onSubmit={handleBooking} className="space-y-5 sm:space-y-6 animate-in fade-in slide-in-from-bottom-4">
          <div className="text-center space-y-1">
            <h3 className="text-xl sm:text-2xl md:text-3xl font-bold text-navy">Finalize booking details</h3>
            <p className="text-xs sm:text-sm text-slate-600">Enter your details to generate your Google Meet video link</p>
          </div>

          <div className="space-y-3.5 sm:space-y-4">
            <div className="space-y-1">
              <label className="mono text-[11px] sm:text-xs text-slate-600 font-bold block">Your Name *</label>
              <Input 
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="bg-white text-navy border-slate-300 rounded-xl h-11 sm:h-12 mono text-xs sm:text-sm focus:border-emerald-600"
              />
            </div>
            
            <div className="space-y-1">
              <label className="mono text-[11px] sm:text-xs text-slate-600 font-bold block">Email *</label>
              <Input 
                required
                name="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="bg-white text-navy border-slate-300 rounded-xl h-11 sm:h-12 mono text-xs sm:text-sm focus:border-emerald-600"
              />
            </div>

            <div className="space-y-1">
              <label className="mono text-[11px] sm:text-xs text-slate-600 font-bold block">What are you looking to build or solve? (Optional)</label>
              <Textarea 
                value={formData.businessNotes}
                onChange={(e) => setFormData({ ...formData, businessNotes: e.target.value })}
                className="bg-white text-navy border-slate-300 rounded-xl mono text-xs sm:text-sm focus:border-emerald-600 resize-none"
                rows={3}
              />
            </div>
          </div>

          <div className="bg-slate-50 border border-slate-200 p-3.5 sm:p-5 space-y-2 sm:space-y-3 text-xs sm:text-sm">
            <div className="flex justify-between items-center border-b border-slate-200 pb-2">
              <span className="mono text-[10px] sm:text-xs tracking-wider text-slate-500 font-bold">Date</span>
              <span className="font-bold text-navy">{format(selectedDate, 'MMMM dd, yyyy')}</span>
            </div>
            <div className="flex justify-between items-center border-b border-slate-200 pb-2">
              <span className="mono text-[10px] sm:text-xs tracking-wider text-slate-500 font-bold">Time</span>
              <span className="font-bold text-navy">{convertToUserTime(selectedTime!)} ({userTimezone})</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="mono text-[10px] sm:text-xs tracking-wider text-slate-500 font-bold">Platform</span>
              <span className="font-bold text-emerald-700">Google Meet</span>
            </div>
          </div>

          {/* Honeypot. Positioned off screen so people never see it; bots fill it in.
          The booking endpoint drops any submission where it has a value. */}
      <input
        type="text"
        name="_gotcha"
        tabIndex={-1}
        autoComplete="off"
        aria-hidden="true"
        value={botField}
        onChange={(ev) => setBotField(ev.target.value)}
        className="absolute left-[-9999px] w-px h-px opacity-0"
      />

          <div className="grid grid-cols-2 gap-3 sm:gap-4">
            <Button type="button" variant="outline" onClick={() => setStep(1)} disabled={isSending} className="border-slate-300 text-zinc-800 hover:bg-slate-100 py-5 sm:py-6 rounded-xl font-bold text-[11px] sm:text-xs">
              Back
            </Button>
            <Button 
              type="submit"
              disabled={!formData.name || !formData.email || isSending}
              className="bg-emerald-600 hover:bg-emerald-700 text-white py-5 sm:py-6 rounded-xl font-bold text-[11px] sm:text-xs flex items-center justify-center gap-2 btn-hover"
            >
              {isSending ? <Loader2 className="animate-spin" size={16} /> : "Confirm Session"}
            </Button>
          </div>
        </form>
      )}

      {step === 3 && (
        <div className="text-center py-8 sm:py-12 space-y-4 sm:space-y-5 animate-in zoom-in-95">
          <div className="w-14 h-14 sm:w-16 sm:h-16 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto">
            <CheckCircle2 size={32} />
          </div>
          <h3 className="text-2xl sm:text-3xl font-bold text-navy">Booking confirmed</h3>
          <p className="text-slate-600 text-xs sm:text-sm max-w-md mx-auto leading-relaxed">
            Your strategy session with Maria is in the calendar for <span className="text-navy font-bold">{format(selectedDate, 'MMMM dd')} at {convertToUserTime(selectedTime!)}</span>. The invite is on its way to <span className="text-emerald-700 font-bold">{formData.email}</span>.
          </p>
          {meetLink && (
            <div className="space-y-2">
              <p className="mono text-[10px] sm:text-xs tracking-wider text-slate-500 font-bold">Your Google Meet link</p>
              <a
                href={meetLink}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-block mono text-xs sm:text-sm text-emerald-700 font-bold underline break-all px-4"
              >
                {meetLink}
              </a>
            </div>
          )}
          <Button asChild variant="outline" className="border-slate-300 text-navy py-4 sm:py-5 px-6 sm:px-8 rounded-xl font-bold hover:bg-slate-100 text-xs">
            <a href="/">Return Home</a>
          </Button>
        </div>
      )}
    </div>
  );
};

export default BookingSystem;