"use client";

import React, { useState } from 'react';
import { useBookingModal } from '@/components/booking/BookingModalProvider';
import { ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { trackEvent } from '@/utils/analytics';

/**
 * Low friction first step on the homepage.
 *
 * Asking for an email is a much smaller ask than a five field form, so the hero
 * collects just that and hands it to the contact form, which reads it from the
 * query string and prefills the email field. Nothing is sent from here: the
 * actual submission still happens on /contact, so there is one place that talks
 * to Formspree and one place that handles errors.
 */
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

interface EmailCaptureCTAProps {
  label?: string;
  className?: string;
}

export const EmailCaptureCTA: React.FC<EmailCaptureCTAProps> = ({
  label = 'Book a call',
  className = '',
}) => {
  const [email, setEmail] = useState('');
  const [error, setError] = useState<string | null>(null);
  const { openBooking } = useBookingModal();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const value = email.trim();

    if (!value) {
      setError('Pop your email in and we will open the booking form.');
      return;
    }
    if (!EMAIL_PATTERN.test(value)) {
      setError('That does not look like an email address. Mind checking it?');
      return;
    }

    setError(null);
    trackEvent("email_capture_submit");
    openBooking(value);
  };

  return (
    <div className={className}>
      <form
        onSubmit={handleSubmit}
        noValidate
        className="flex flex-col sm:flex-row gap-3 w-full max-w-xl mx-auto"
      >
        <label htmlFor="hero-email" className="sr-only">
          Your email address
        </label>
        <input
          id="hero-email"
          type="email"
          inputMode="email"
          autoComplete="email"
          placeholder="your@email.com"
          value={email}
          onChange={(e) => {
            setEmail(e.target.value);
            if (error) setError(null);
          }}
          aria-invalid={error ? true : undefined}
          aria-describedby={error ? 'hero-email-error' : undefined}
          className="flex-1 min-w-0 min-h-[56px] sm:min-h-[64px] border border-slate-300 bg-white px-4 text-sm sm:text-base text-navy placeholder:text-slate-400 rounded-xl focus:outline-none focus:border-emerald-600 focus:ring-1 focus:ring-emerald-600 transition-colors"
        />
        <Button
          type="submit"
          className="bg-emerald-600 hover:bg-emerald-700 text-white px-6 sm:px-8 min-h-[56px] sm:min-h-[64px] h-auto rounded-xl font-bold text-xs sm:text-base tracking-tight btn-hover shadow-md shrink-0"
        >
          {label} <ArrowRight size={16} className="ml-1.5" />
        </Button>
      </form>

      {error ? (
        <p
          id="hero-email-error"
          role="alert"
          className="mt-2.5 text-sm text-rose-700 text-center sm:text-left max-w-xl mx-auto"
        >
          {error}
        </p>
      ) : (
        <p className="mt-2.5 mono text-[11px] tracking-wider text-slate-500 text-center max-w-xl mx-auto">
          Free 30 minute call. No obligation, and we will tell you if you do not need us.
        </p>
      )}
    </div>
  );
};

export default EmailCaptureCTA;
