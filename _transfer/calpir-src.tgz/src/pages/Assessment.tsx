"use client";

import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { RefreshCcw, Zap, Lock, Sparkles, Loader2 } from 'lucide-react';
import { Link } from 'react-router-dom';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import SectionLabel from '@/components/ui/SectionLabel';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import PhoneInput from '@/components/ui/PhoneInput';
import { cn } from '@/lib/utils';
import { showSuccess, showError } from '@/utils/toast';
import { trackLeadGeneration } from '@/utils/analytics';
import MetaSEO from '@/components/seo/MetaSEO';

interface QuestionOption {
  label: string;
  value: string | number;
}

interface Question {
  id: string;
  title: string;
  options: QuestionOption[];
}

const questions: Question[] = [
  {
    id: 'stage',
    title: "What stage is your business at right now?",
    options: [
      { label: "Pre launch: I have a clear idea and want to launch properly", value: "pre-launch" },
      { label: "Just launched: Under 6 months, getting initial customers", value: "just-launched" },
      { label: "Growing: 6 months to 2 years, ready to automate and scale", value: "growing" },
      { label: "Established: 2+ years, modernising infrastructure with AI", value: "established" }
    ]
  },
  {
    id: 'burn',
    title: "What is your current monthly budget or operating capital?",
    options: [
      { label: "Under $1,000 (Lean Bootstrapped)", value: "low" },
      { label: "$1,000 to $5,000", value: "mid" },
      { label: "$5,000 to $20,000", value: "high" },
      { label: "$20,000+ (Rapid Growth or Funded)", value: "vc" }
    ]
  },
  {
    id: 'website',
    title: "How is your current website situation?",
    options: [
      { label: "No website or registered domain yet", value: "none" },
      { label: "I have a slow outdated site that barely converts", value: "outdated" },
      { label: "Decent site, but needs modern speed and automations", value: "decent" },
      { label: "Fast custom site, looking to connect AI and CRM", value: "pro" }
    ]
  },
  {
    id: 'crm',
    title: "How are you tracking leads and client conversations?",
    options: [
      { label: "Notes, spreadsheets, DMs, or memory", value: "manual" },
      { label: "A CRM I set up myself that is messy and unautomated", value: "messy" },
      { label: "Properly configured CRM with automated pipelines", value: "pro" },
      { label: "We do not consistently capture or track leads yet", value: "none" }
    ]
  },
  {
    id: 'hours',
    title: "How many hours each week do you spend on repetitive admin work?",
    options: [
      { label: "5 hours or fewer", value: 5 },
      { label: "5 to 15 hours", value: 15 },
      { label: "15 to 25 hours", value: 25 },
      { label: "25+ hours every week", value: 40 }
    ]
  },
  {
    id: 'bottleneck',
    title: "What is your number one priority or bottleneck?",
    options: [
      { label: "Getting online fast with Google ranking and instant trust", value: "visibility" },
      { label: "Turning more website visitors into paying clients", value: "conversion" },
      { label: "Faster lead response times so deals stop going cold", value: "leads" },
      { label: "Automating repetitive copy-pasting and manual admin", value: "manual" },
      { label: "Unifying 6 disconnected apps into one sync engine", value: "systems" },
      { label: "Deploying 24/7 autonomous AI support agents", value: "ai" }
    ]
  }
];

const Assessment = () => {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [showResults, setShowResults] = useState(false);
  const [userEmail, setUserEmail] = useState('');
  const [userName, setUserName] = useState('');
  const [userPhone, setUserPhone] = useState('');
  const [botField, setBotField] = useState('');
  const [isSendingReport, setIsSendingReport] = useState(false);
  const [isReportUnlocked, setIsReportUnlocked] = useState(false);

  const handleAnswer = (value: any) => {
    const currentQ = questions[step];
    const newAnswers = { ...answers, [currentQ.id]: value };
    setAnswers(newAnswers);
    if (step < questions.length - 1) {
      setStep(step + 1);
    } else {
      setShowResults(true);
    }
  };

  const calculateResults = () => {
    const rawHours = Number(answers.hours) || 15;
    const wastedMoney = rawHours * 50 * 4;
    const annualWaste = wastedMoney * 12;

    const recommendations = [
      {
        title: "Domain Setup, SSL Certificate and Instant Google Search Indexing",
        desc: "We secure your custom domain, activate 256-bit SSL encryption, and submit XML sitemaps to Google Search Console for day one indexing."
      },
      {
        title: "Sub-1.5s High-Conversion Web Architecture",
        desc: "Upgrade to modern React and Next.js edge architecture designed for high conversion, mobile responsiveness, and 100/100 Core Web Vitals."
      },
      {
        title: "Automated CRM and 60-Second Lead Routing",
        desc: "Deploy HubSpot or GoHighLevel with instant SMS alerts so every new inquiry is contacted within 60 seconds."
      },
      {
        title: "Autonomous RAG AI Agent Fleet",
        desc: "Deploy 24/7 intelligent agents trained on your business data to qualify leads, answer FAQs, and book calendar appointments automatically."
      }
    ];

    return { wastedMoney, annualWaste, rawHours, recommendations };
  };

  const results = calculateResults();

  const handleSendReport = async (e: React.FormEvent) => {
    e.preventDefault();
    // Honeypot: only a bot fills this in.
    if (botField.trim() !== '') return;
    setIsSendingReport(true);

    try {
      const response = await fetch('https://formspree.io/f/moearjyk', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          _gotcha: botField,
          recipientName: userName,
          email: userEmail,
          phone: userPhone || 'Not provided',
          stage: answers.stage,
          budgetTier: answers.burn,
          websiteState: answers.website,
          crmState: answers.crm,
          weeklyWastedHours: answers.hours,
          primaryBottleneck: answers.bottleneck,
          monthlyFinancialLoss: `$${results.wastedMoney.toLocaleString()}`,
          annualFinancialLoss: `$${results.annualWaste.toLocaleString()}`,
          message: `Assessment completed by ${userName}. Stage: ${answers.stage}. Bottleneck: ${answers.bottleneck}. Potential annual savings: $${results.annualWaste.toLocaleString()}`
        })
      });

      if (response.ok) {
        trackLeadGeneration("assessment");
        setIsReportUnlocked(true);
        showSuccess("Full custom architecture report unlocked and sent to your email!");
      } else {
        showError("Unable to transmit report. Please email info@calpir.com directly.");
      }
    } catch (err) {
      showError("Connection error. Please reach out to info@calpir.com and we will pick it up.");
    } finally {
      setIsSendingReport(false);
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <MetaSEO 
        title="Free Business Assessment | Calpir"
        description="Answer a few questions and get a clear picture of which parts of your business are ready to automate."
        path="/assessment"
      />
      <Navbar />

      <main className="pt-36 md:pt-44 pb-24 px-4 md:px-6">
        <div className="container-custom max-w-4xl">
          {!showResults ? (
            <div>
              <div className="mb-12">
                <div className="flex justify-between items-end mb-4">
                  <span className="text-emerald-800 mono font-bold tracking-wide text-xs">
                    Question {step + 1} of {questions.length}
                  </span>
                  <span className="text-slate-600 mono font-bold text-xs">
                    {Math.round(((step + 1) / questions.length) * 100)}% Complete
                  </span>
                </div>
                <Progress value={((step + 1) / questions.length) * 100} className="h-2 bg-zinc-200" />
              </div>

              <AnimatePresence mode="wait">
                <motion.div
                  key={step}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                  className="space-y-8"
                >
                  <h1 className="text-3xl sm:text-5xl md:text-6xl font-bold tracking-tight text-navy leading-tight">
                    {questions[step].title}
                  </h1>
                  <div className="grid grid-cols-1 gap-3.5">
                    {questions[step].options.map((opt) => (
                      <button
                        key={String(opt.value)}
                        type="button"
                        onClick={() => handleAnswer(opt.value)}
                        className={cn(
                          "p-6 md:p-7 text-left border transition-all font-bold text-base md:text-lg tracking-tight",
                          answers[questions[step].id] === opt.value
                            ? "border-emerald-600 bg-emerald-50 text-emerald-950 shadow-sm"
                            : "border-slate-200 bg-slate-50 text-navy hover:border-emerald-600 hover:bg-white"
                        )}
                      >
                        {opt.label}
                      </button>
                    ))}
                  </div>
                </motion.div>
              </AnimatePresence>
            </div>
          ) : (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="space-y-12">
              <div className="text-center">
                <SectionLabel>Analysis Complete</SectionLabel>
                <h1 className="text-4xl sm:text-6xl md:text-7xl font-bold tracking-tight text-navy mb-4">
                  Your Systems <br /> <span className="text-emerald-700">Blueprint</span>
                </h1>
                <p className="text-lg md:text-xl text-slate-600 max-w-2xl mx-auto">
                  We have mapped out your exact operational bottlenecks and projected ROI improvements.
                </p>
              </div>

              {/* Preliminary Metrics */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="border border-rose-200 p-8 bg-rose-50/60 shadow-sm">
                  <div className="mono text-xs tracking-wide text-rose-700 font-bold mb-3">
                    Estimated Monthly Financial Drag (Action Required)
                  </div>
                  <div className="text-5xl md:text-6xl font-bold text-rose-600 mb-3">
                    ${results.wastedMoney.toLocaleString()}
                  </div>
                  <p className="mono text-xs md:text-sm text-slate-600 leading-relaxed">
                    Based on {results.rawHours} hours per week of manual admin, you are losing <strong className="text-rose-700">${(results.annualWaste).toLocaleString()}</strong> every year in preventable overhead.
                  </p>
                </div>

                <div className="border border-emerald-200 p-8 bg-emerald-50/70 shadow-sm">
                  <div className="mono text-xs tracking-wide text-emerald-800 font-bold mb-3">
                    Primary Strategic Objective
                  </div>
                  <h3 className="text-2xl md:text-3xl font-bold text-navy mb-3">
                    System synchronization
                  </h3>
                  <p className="mono text-xs md:text-sm text-slate-600 leading-relaxed">
                    Eliminate your operational bottleneck by connecting your website, CRM, and AI workflows into one smooth self-running engine.
                  </p>
                </div>
              </div>

              {/* Gate with Formspree */}
              {!isReportUnlocked ? (
                <div className="border-2 border-emerald-600 bg-white p-6 md:p-10 shadow-xl relative">
                  <div className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-emerald-600 text-white px-4 py-1 mono text-xs tracking-wide font-bold flex items-center gap-1.5 shadow-sm">
                    <Lock size={13} /> Full Report Ready To Dispatch
                  </div>

                  <div className="text-center max-w-xl mx-auto space-y-3 mb-8 pt-2">
                    <h3 className="text-2xl sm:text-3xl font-bold text-navy tracking-tight">
                      Unlock your complete 8-Page infrastructure blueprint
                    </h3>
                    <p className="text-slate-600 text-xs md:text-sm leading-relaxed mono">
                      Enter your details below to instantly view your tailored module roadmap and receive the PDF copy in your inbox.
                    </p>
                  </div>

                  <form onSubmit={handleSendReport} className="max-w-md mx-auto space-y-4">
                    <div>
                      <label className="mono text-[11px] text-slate-600 font-bold block mb-1.5">
                        Your Full Name *
                      </label>
                      <Input
                        required
                        placeholder="Alex Smith"
                        value={userName}
                        onChange={(e) => setUserName(e.target.value)}
                        className="bg-white text-navy border-slate-300 rounded-xl h-12 mono text-sm focus:border-emerald-600"
                      />
                    </div>

                    <div>
                      <label className="mono text-[11px] text-slate-600 font-bold block mb-1.5">
                        Email *
                      </label>
                      <Input
                        required
                        type="email"
                        name="email"
                        placeholder="alex@example.com"
                        value={userEmail}
                        onChange={(e) => setUserEmail(e.target.value)}
                        className="bg-white text-navy border-slate-300 rounded-xl h-12 mono text-sm focus:border-emerald-600"
                      />
                    </div>

                    <div>
                      <label className="mono text-[11px] text-slate-600 font-bold block mb-1.5">
                        Phone / WhatsApp (Optional)
                      </label>
                      <PhoneInput
                        value={userPhone}
                        onChange={(val) => setUserPhone(val)}
                        placeholder="Your number"
                      />
                    </div>

                    {/* Human Verification */}
                    <div className="pt-1">
                      {/* Honeypot. Positioned off screen so people never see it; bots fill it in.
          Also sent to Formspree as _gotcha, which drops the submission server side. */}
      <input
        type="text"
        name="_gotcha"
        tabIndex={-1}
        autoComplete="off"
        aria-hidden="true"
        value={botField}
        onChange={(ev) => setBotField(ev.target.value)}
        className="absolute left-[-9999px] w-px h-px opacity-0"
      />

      
                    </div>

                    <Button
                      type="submit"
                      disabled={isSendingReport || !userEmail || !userName}
                      className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-7 rounded-xl font-bold text-base md:text-lg tracking-tight btn-hover flex items-center justify-center gap-2"
                    >
                      {isSendingReport ? (
                        <Loader2 className="animate-spin" />
                      ) : (
                        <>
                          <Sparkles size={18} /> Unlock and Send Full Report
                        </>
                      )}
                    </Button>
                  </form>
                </div>
              ) : (
                <div className="space-y-10 animate-in fade-in duration-500">
                  <div className="p-5 bg-emerald-50 border border-emerald-300 text-center mono text-xs md:text-sm text-emerald-900 font-bold">
                    ✓ Full Architecture Report Dispatched to <span className="text-navy font-bold">{userEmail}</span>
                  </div>

                  <div className="space-y-4">
                    <SectionLabel>Your Recommended Execution Modules</SectionLabel>
                    <div className="grid grid-cols-1 gap-4">
                      {results.recommendations.map((s, i) => (
                        <div key={i} className="border border-slate-200 p-6 md:p-8 bg-slate-50 flex flex-col md:flex-row gap-5 items-start">
                          <div className="w-12 h-12 bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-sm">
                            <Zap size={24} />
                          </div>
                          <div>
                            <h4 className="text-xl md:text-2xl font-bold text-navy mb-1.5">{s.title}</h4>
                            <p className="mono text-xs md:text-sm text-slate-600 leading-relaxed">{s.desc}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-emerald-600 text-white p-8 md:p-12 text-center space-y-4 shadow-lg">
                    <h3 className="text-2xl sm:text-4xl font-bold tracking-tight">
                      Ready to deploy this infrastructure?
                    </h3>
                    <p className="text-emerald-100 font-bold max-w-lg mx-auto text-sm md:text-base">
                      Book a free 30 minute strategy session with Maria to review your custom blueprint together.
                    </p>
                    <div className="pt-2">
                      <Button asChild className="bg-navy text-white hover:bg-navy-800 px-10 py-6 rounded-xl font-bold text-base tracking-tight transition-all">
                        <Link to="/contact">Book Free Strategy Session with Maria</Link>
                      </Button>
                    </div>
                  </div>
                </div>
              )}

              <div className="flex justify-center pt-4">
                <Button
                  variant="outline"
                  className="border-slate-300 text-navy py-6 px-8 rounded-xl font-bold text-xs tracking-wider hover:bg-slate-100"
                  onClick={() => {
                    setStep(0);
                    setAnswers({});
                    setShowResults(false);
                    setIsReportUnlocked(false);
                  }}
                >
                  <RefreshCcw className="mr-2" size={16} /> Retake Assessment
                </Button>
              </div>
            </motion.div>
          )}
        </div>
      </main>

      <Footer />
    </div>
  );
};

export default Assessment;