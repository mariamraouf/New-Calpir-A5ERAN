"use client";

import React, { useState, useEffect, useRef } from 'react';
import { Mail, Phone, MapPin, Sparkles, Loader2, CheckCircle2, Send } from 'lucide-react';
import Navbar from '@/components/layout/Navbar';
import Footer from '@/components/layout/Footer';
import PageHero from '@/components/ui/PageHero';
import { PLAN_PHOTOS, TEAM_PHOTO, BUILD_PHOTO, OWNER_PHOTO } from '@/data/planPhotos';
import SectionLabel from '@/components/ui/SectionLabel';
import BookingSystem from '@/components/booking/BookingSystem';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import PhoneInput from '@/components/ui/PhoneInput';
import { showSuccess, showError } from '@/utils/toast';
import { trackLeadGeneration } from '@/utils/analytics';
import MetaSEO from '@/components/seo/MetaSEO';

const Contact = () => {
  const formRef = useRef<HTMLDivElement>(null);

  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    package: '',
    message: ''
  });
  const [botField, setBotField] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    // Honeypot: only a bot fills this in.
    if (botField.trim() !== '') return;
    setIsSubmitting(true);

    try {
      const response = await fetch('https://formspree.io/f/xlgalgka', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Accept': 'application/json'
        },
        body: JSON.stringify({
          _gotcha: botField,
          name: formData.name,
          email: formData.email,
          phone: formData.phone || 'Not provided',
          interestedPackage: formData.package,
          message: formData.message
        })
      });

      if (response.ok) {
        trackLeadGeneration("contact_page");
        setIsSubmitted(true);
        showSuccess("Message received! Our team will respond within 4 hours.");
      } else {
        showError("There was an issue sending your message. Please email info@calpir.com directly.");
      }
    } catch {
      showError("Submission error. Please email us at info@calpir.com and we will pick it up.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-white">
      <MetaSEO 
        title="Contact Calpir | Book Free Strategy Call"
        description="Get in touch with Calpir technical directors or book a live 30-minute consultation with Maria."
        path="/contact"
      />
      <Navbar />
      
      <PageHero
        compact
        eyebrow="Talk to us"
        title={<>Tell us what you <br />want built.</>}
        body="Say what the business is and what is in your way. You get a straight answer, a named thing and a number, whether or not you end up buying anything."
        image={PLAN_PHOTOS['hr-admin-monthly'].band}
      />

      <section className="py-16 md:py-20 px-4 md:px-6 border-b border-slate-200">
        <div className="container-custom">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-start">
            {/* Squad Contact Details */}
            <div className="space-y-8">
              <SectionLabel>Direct Channels</SectionLabel>
              <h2 className="text-3xl md:text-4xl font-bold text-navy tracking-tight">
                Let's build something meaningful together.
              </h2>
              <p className="text-slate-600 text-sm md:text-base leading-relaxed">
                Whether you need a full 7 day launch package, custom AI agents, or specific à la carte setup, we respond fast with zero corporate fluff.
              </p>
              
              <div className="space-y-4 pt-2">
                <div className="flex items-center gap-4 p-4 border border-slate-200 bg-slate-50 shadow-sm">
                  <div className="text-emerald-700 p-3 bg-emerald-100/70 border border-emerald-300">
                    <Mail size={22} />
                  </div>
                  <div>
                    <div className="mono text-xs tracking-wider text-slate-500 font-bold">Email Our Team</div>
                    <a href="mailto:info@calpir.com" className="text-base md:text-lg font-bold text-navy hover:text-emerald-700 transition-colors">
                      info@calpir.com
                    </a>
                  </div>
                </div>

              </div>

              <div className="p-5 border border-emerald-200 bg-emerald-50 space-y-1.5 shadow-sm">
                <div className="flex items-center gap-2 text-emerald-800 mono text-xs font-bold">
                  <Sparkles size={14} className="text-emerald-600" /> Squad Response Guarantee
                </div>
                <p className="text-xs text-slate-600 leading-relaxed mono">
                  We reply within 4 business hours. You talk directly with senior technical leads who build systems every day.
                </p>
              </div>
            </div>

            {/* Contact Form */}
            <div
              id="book"
              ref={formRef}
              className="border border-slate-200 bg-white p-6 md:p-10 shadow-lg scroll-mt-28"
            >
              {!isSubmitted ? (
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="mono text-xs tracking-wide text-emerald-800 font-bold">
                    Project Request Form
                  </div>
                  <h3 className="text-2xl md:text-3xl font-bold text-navy tracking-tight">
                    Send us your requirements
                  </h3>

                  <div className="space-y-1.5">
                    <label className="mono text-xs text-slate-600 font-bold block">
                      Your Full Name *
                    </label>
                    <Input
                      required
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      className="bg-white text-navy border-slate-300 rounded-xl h-12 mono text-sm focus:border-emerald-600"
                    />
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <label className="mono text-xs text-slate-600 font-bold block">
                        Email *
                      </label>
                      <Input
                        required
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="bg-white text-navy border-slate-300 rounded-xl h-12 mono text-sm focus:border-emerald-600"
                      />
                    </div>
                    <div className="space-y-1.5">
                      <label className="mono text-xs text-slate-600 font-bold block">
                        Phone / WhatsApp
                      </label>
                      <PhoneInput
                        value={formData.phone}
                        onChange={(val) => setFormData({ ...formData, phone: val })}
                      />
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    <label className="mono text-xs text-slate-600 font-bold block">
                      Interested Package or Solo Service
                    </label>
                    <select
                      value={formData.package}
                      onChange={(e) => setFormData({ ...formData, package: e.target.value })}
                      className="w-full bg-white text-navy border border-slate-300 rounded-xl h-12 px-3 mono text-xs focus:border-emerald-600 cursor-pointer"
                    >
                      <option value="Starter Launch Package ($1,499)">Starter Launch Package ($1,499)</option>
                      <option value="Growth Launch Package ($3,499)">Growth Launch Package ($3,499)</option>
                      <option value="Ultimate Launch Package ($6,999)">Ultimate Launch Package ($6,999)</option>
                      <option value="Solo: Domain & SSL Setup ($149)">Solo: Domain & SSL Setup ($149)</option>
                      <option value="Solo: Google GBP & Indexing ($199)">Solo: Google GBP & Indexing ($199)</option>
                      <option value="Solo: Branding & Palettes ($399)">Solo: Branding, Fonts & Palettes ($399)</option>
                      <option value="Solo: CRM Pipeline Setup ($599)">Solo: Custom CRM Pipeline ($599)</option>
                      <option value="Solo: AI Customer Support Agent ($699)">Solo: Custom AI Agent ($699)</option>
                      <option value="Solo: Video Editing Pack ($299)">Solo: Video Editing Suite ($299)</option>
                      <option value="Custom App or Web Software">Custom App or Web Software</option>
                    </select>
                  </div>

                  <div className="space-y-1.5">
                    <label className="mono text-xs text-slate-600 font-bold block">
                      Project Details & Goals *
                    </label>
                    <Textarea
                      required
                      name="message"
                      rows={4}
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="bg-white text-navy border-slate-300 rounded-xl mono text-sm focus:border-emerald-600 resize-none"
                    />
                  </div>

                  {/* Honeypot. Positioned off screen so people never see it; bots fill it in.
          Also sent to Formspree as _gotcha, which drops the submission server side. */}
      <input
        type="text"
        name="_gotcha"
        tabIndex={-1}
        autoComplete="off"
        aria-hidden="true"
        value={botField}
        onChange={(ev) => setBotField(ev.target.value)}
        className="absolute left-[-9999px] w-px h-px opacity-0"
      />

                  <Button
                    type="submit"
                    disabled={isSubmitting}
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white py-7 rounded-xl font-bold text-base md:text-lg tracking-tight btn-hover flex items-center justify-center gap-2"
                  >
                    {isSubmitting ? (
                      <Loader2 className="animate-spin" />
                    ) : (
                      <>
                        <Send size={18} /> Send Message to Our Squad
                      </>
                    )}
                  </Button>
                </form>
              ) : (
                <div className="text-center py-10 space-y-5">
                  <div className="w-14 h-14 bg-emerald-100 text-emerald-700 rounded-full flex items-center justify-center mx-auto">
                    <CheckCircle2 size={32} />
                  </div>
                  <h3 className="text-2xl md:text-3xl font-bold text-navy tracking-tight">Transmission received</h3>
                  <p className="text-slate-600 text-sm max-w-sm mx-auto leading-relaxed">
                    Thank you {formData.name}. We are reviewing your requirements and will reply to <span className="text-navy font-bold">{formData.email}</span> shortly.
                  </p>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setIsSubmitted(false);
                      setFormData({ name: '', email: '', phone: '', package: 'Starter Launch Package ($1,499)', message: '' });
                    }}
                    className="border-slate-300 text-navy rounded-xl mono text-xs font-bold hover:bg-slate-100"
                  >
                    Send Another Message
                  </Button>
                </div>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Booking Section */}
      <section className="section-padding bg-slate-50/60">
        <div className="container-custom">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-10">
              <SectionLabel>Live Consultation</SectionLabel>
              <h2 className="text-3xl sm:text-5xl md:text-6xl font-bold tracking-tight text-navy mb-3">
                Book with maria.
              </h2>
              <p className="text-base md:text-lg text-slate-600 leading-relaxed max-w-xl mx-auto">
                Select a time for your 30 minute strategy session. Times are automatically adjusted to your local timezone.
              </p>
            </div>
            <BookingSystem />
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Contact;