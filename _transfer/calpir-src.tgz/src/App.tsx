import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import Services from "./pages/Services";
import ServiceDetail from "./pages/ServiceDetail";
import Packages from "./pages/Packages";
import SoloServices from "./pages/SoloServices";
import SoftwareStack from "./pages/SoftwareStack";
import About from "./pages/About";
import CaseStudies from "./pages/CaseStudies";
import Assessment from "./pages/Assessment";
import Blog from "./pages/Blog";
import BlogPost from "./pages/BlogPost";
import Contact from "./pages/Contact";
import NotFound from "./pages/NotFound";
import ScrollToTopOnRoute from "./components/ui/ScrollToTopOnRoute";
import CheckoutSuccess from "./pages/CheckoutSuccess";
import Pricing from "./pages/Pricing";
import MarketingSeo from "./pages/MarketingSeo";
import BookingModalProvider from "./components/booking/BookingModalProvider";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <ScrollToTopOnRoute />
        <BookingModalProvider>
        <Routes>
          <Route path="/" element={<Index />} />
          <Route path="/services" element={<Services />} />
          <Route path="/services/:slug" element={<ServiceDetail />} />
          <Route path="/pricing" element={<Pricing />} />
          <Route path="/packages" element={<Packages />} />
          <Route path="/marketing-seo" element={<MarketingSeo />} />
          <Route path="/checkout/success" element={<CheckoutSuccess />} />
          <Route path="/solo-services" element={<SoloServices />} />
          <Route path="/software-stack" element={<SoftwareStack />} />
          <Route path="/about" element={<About />} />
          <Route path="/case-studies" element={<CaseStudies />} />
          <Route path="/assessment" element={<Assessment />} />
          <Route path="/blog" element={<Blog />} />
          <Route path="/blog/:slug" element={<BlogPost />} />
          <Route path="/contact" element={<Contact />} />
          <Route path="*" element={<NotFound />} />
        </Routes>
        </BookingModalProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;