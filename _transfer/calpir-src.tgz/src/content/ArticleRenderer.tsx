"use client";

import React from 'react';
import { Link } from 'react-router-dom';

/**
 * Renders a blog article from the block model in src/content/articleBlocks.json.
 *
 * Block types: lead, p, h2, h3, ul, ol, table, note, faq, sources
 * Inline token: { s: text, b?: bold, h?: href }
 *
 * House style matches the rest of the site:
 *   lead   text-2xl font-black uppercase, emerald left rule
 *   h2     text-3xl font-black uppercase, top border
 *   h3     text-xl font-bold emerald, uppercase
 *   table  zinc-950 header, zebra rows, horizontal scroll on small screens
 */

export interface Tok { s: string; b?: boolean; h?: string }
export interface Block {
  t: string;
  x?: Tok[];
  items?: any[];
  head?: string[];
  rows?: Tok[][][];
}

const Inline: React.FC<{ x?: Tok[] }> = ({ x }) => (
  <>
    {(x || []).map((tok, i) => {
      if (tok.h) {
        const internal = tok.h.startsWith('/');
        return internal ? (
          <Link
            key={i}
            to={tok.h}
            className="text-emerald-700 underline underline-offset-4 hover:text-emerald-900"
          >
            {tok.s}
          </Link>
        ) : (
          <a
            key={i}
            href={tok.h}
            target="_blank"
            rel="noopener noreferrer"
            className="text-emerald-700 underline underline-offset-4 hover:text-emerald-900"
          >
            {tok.s}
          </a>
        );
      }
      if (tok.b) return <strong key={i} className="text-navy font-bold">{tok.s}</strong>;
      return <React.Fragment key={i}>{tok.s}</React.Fragment>;
    })}
  </>
);

const ArticleRenderer: React.FC<{ blocks: Block[] }> = ({ blocks }) => (
  <div className="article-prose space-y-7">
    {blocks.map((b, i) => {
      switch (b.t) {
        case 'lead':
          return (
            <p
              key={i}
              className="text-lg md:text-xl text-navy font-semibold border-l-4 border-emerald-600 pl-6 py-4 bg-emerald-50/70 !max-w-none"
            >
              <Inline x={b.x} />
            </p>
          );

        case 'h2':
          return (
            <h2
              key={i}
              className="text-2xl md:text-[1.75rem] font-bold text-navy pt-10 mt-2 border-t border-slate-200 leading-snug"
            >
              <Inline x={b.x} />
            </h2>
          );

        case 'h3':
          return (
            <h3 key={i} className="text-lg md:text-xl font-bold text-emerald-800 pt-4 leading-snug">
              <Inline x={b.x} />
            </h3>
          );

        case 'p':
          return (
            <p key={i}>
              <Inline x={b.x} />
            </p>
          );

        case 'note':
          return (
            <p key={i} className="text-sm text-slate-500 border-l-2 border-slate-300 pl-4 !max-w-[64ch]">
              <Inline x={b.x} />
            </p>
          );

        case 'ul':
          return (
            <ul key={i} className="list-disc pl-6 space-y-2.5 marker:text-emerald-600">
              {(b.items as Tok[][]).map((it, j) => (
                <li key={j}><Inline x={it} /></li>
              ))}
            </ul>
          );

        case 'ol':
          return (
            <ol key={i} className="list-decimal pl-6 space-y-2.5 marker:text-emerald-600 marker:font-bold">
              {(b.items as Tok[][]).map((it, j) => (
                <li key={j}><Inline x={it} /></li>
              ))}
            </ol>
          );

        case 'table':
          return (
            <div key={i} className="overflow-x-auto my-8 border border-slate-200 shadow-sm">
              <table className="w-full text-left">
                <thead className="bg-navy text-white">
                  <tr>
                    {(b.head || []).map((h, j) => (
                      <th
                        key={j}
                        className="px-4 py-3 font-bold tracking-wider text-xs whitespace-nowrap"
                      >
                        {h}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {(b.rows || []).map((row, r) => (
                    <tr key={r} className={r % 2 ? 'bg-slate-50' : 'bg-white'}>
                      {row.map((cell, c) => (
                        <td
                          key={c}
                          className={
                            c === 0
                              ? 'px-4 py-3 border-t border-slate-200 font-bold text-navy align-top'
                              : 'px-4 py-3 border-t border-slate-200 text-slate-600 align-top'
                          }
                        >
                          <Inline x={cell} />
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          );

        case 'faq':
          return (
            <div key={i} className="pt-8 border-t border-slate-200">
              <h2 className="text-2xl md:text-[1.75rem] font-bold text-navy mb-8 leading-snug">
                Frequently asked questions
              </h2>
              <div className="space-y-px bg-zinc-200 border border-slate-200">
                {(b.items as { q: string; a: string }[]).map((f, j) => (
                  <div key={j} className="bg-white p-6">
                    <h3 className="text-base md:text-lg font-bold text-navy mb-3 leading-snug">{f.q}</h3>
                    <p className="text-base text-slate-600 leading-relaxed">{f.a}</p>
                  </div>
                ))}
              </div>
            </div>
          );

        case 'sources':
          return (
            <div key={i} className="pt-8 border-t border-slate-200">
              <p className="mono text-xs tracking-wide text-emerald-700 font-bold mb-4">
                Sources
              </p>
              <ul className="space-y-2 text-sm text-slate-600">
                {(b.items as { label: string; url: string; note: string }[]).map((s, j) => (
                  <li key={j}>
                    {s.url ? (
                      <a
                        href={s.url}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="text-emerald-700 underline underline-offset-4 hover:text-emerald-900"
                      >
                        {s.label}
                      </a>
                    ) : (
                      s.label
                    )}
                    {s.note ? <span className="text-slate-500">, {s.note}</span> : null}
                  </li>
                ))}
              </ul>
            </div>
          );

        default:
          return null;
      }
    })}
  </div>
);

export default ArticleRenderer;
